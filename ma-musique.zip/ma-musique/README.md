# Ma Musique — guide de mise en ligne

Une web-app personnelle : bibliothèque musicale hors-ligne, mode clair/sombre,
import de titres depuis une playlist Spotify. Installable sur iPhone via
« Ajouter à l'écran d'accueil ».

## 1. Mettre l'app en ligne (gratuit, sans Mac)

Un service comme celui-ci doit être servi en HTTPS pour fonctionner hors-ligne
sur iPhone (obligatoire pour le mode hors-ligne). **GitHub Pages** convient
parfaitement et est gratuit.

1. Crée un compte sur [github.com](https://github.com) si tu n'en as pas.
2. Crée un nouveau dépôt (bouton **New**), nomme-le par exemple `ma-musique`,
   coche **Public**.
3. Dans le dépôt, clique **Add file → Upload files**, puis glisse-dépose
   *tous* les fichiers de ce dossier (`index.html`, `styles.css`, `app.js`,
   `spotify.js`, `sw.js`, `manifest.json`, et le dossier `icons`). Valide
   avec **Commit changes**.
4. Va dans **Settings → Pages**. Dans « Branch », choisis `main` et le
   dossier `/ (root)`, puis **Save**.
5. Après une minute ou deux, ton app est en ligne à une adresse du type :
   `https://TON-PSEUDO.github.io/ma-musique/`

## 2. Installer sur l'iPhone

1. Ouvre cette adresse dans **Safari** sur l'iPhone (obligatoire, pas Chrome).
2. Appuie sur l'icône de partage (carré avec flèche) → **Sur l'écran d'accueil**.
3. L'app apparaît comme une icône normale. Ouvre-la depuis là (pas depuis
   Safari) pour profiter du plein écran et du mode hors-ligne.

## 3. Ajouter tes morceaux

Dans l'onglet **Ajouter**, colle un lien direct vers un fichier audio
(`.mp3`, `.m4a`, `.wav`...) que tu héberges (Dropbox en lien direct,
serveur perso, GitHub, etc.). Le fichier est téléchargé une seule fois et
stocké sur le téléphone : ensuite il est disponible hors-ligne.

**Limite technique à connaître :** certains hébergeurs bloquent le
téléchargement direct depuis un navigateur (règle appelée CORS). Si un lien
échoue avec une erreur, c'est ce blocage — il faut héberger le fichier
ailleurs (un dépôt GitHub public avec le lien "raw" fonctionne bien, par
exemple).

## 4. Import de playlist Spotify (optionnel)

Ceci importe uniquement les **titres et artistes** de ta playlist — Spotify
ne permet pas de télécharger l'audio, quelle que soit l'app utilisée. Chaque
titre importé apparaît dans ta bibliothèque avec un badge « lien manquant » ;
tu n'as plus qu'à taper dessus et coller le lien audio correspondant.

Pour l'activer :
1. Va sur [developer.spotify.com/dashboard](https://developer.spotify.com/dashboard)
   et connecte-toi avec ton compte Spotify (gratuit).
2. **Create app**. Donne un nom, une description.
3. Dans **Redirect URIs**, colle *exactement* l'adresse de ton app déployée,
   par ex. `https://TON-PSEUDO.github.io/ma-musique/index.html`
4. Sauvegarde, ouvre les **Settings** de l'app créée, copie le **Client ID**.
5. Dans l'app, onglet **Réglages**, colle ce Client ID.
6. Dans l'onglet **Ajouter**, colle le lien d'une playlist Spotify et
   appuie sur **Importer les titres**.

## 5. Ce qu'il faut savoir sur la lecture en fond

La lecture continue quand l'écran est verrouillé fonctionne mieux quand
l'app est ouverte depuis l'icône sur l'écran d'accueil (pas depuis un onglet
Safari). Le comportement dépend de la version d'iOS et n'est pas garanti à
100 % comme une app native — Apple restreint volontairement ce que peuvent
faire les web-apps en arrière-plan. Si la lecture coupe trop souvent après
verrouillage, c'est une limite d'iOS pour les web-apps, pas un bug de l'app.

## 6. Mettre à jour l'app plus tard

Si tu modifies les fichiers, re-uploade-les sur GitHub (même méthode qu'à
l'étape 1.3). Pense à changer `CACHE_NAME` dans `sw.js` (ex : `v2`) pour que
le téléphone récupère bien la nouvelle version.
