/* ============================================================
   Import de playlists Spotify — OAuth Authorization Code + PKCE
   Ne récupère que les titres/artistes (pas l'audio, que Spotify
   ne permet pas de télécharger). Aucun secret client requis :
   tout se passe côté navigateur avec le Client ID de l'utilisateur.
   ============================================================ */

const SpotifyImport = (() => {
  const SCOPE = "playlist-read-private playlist-read-collaborative";

  function redirectUri() {
    // La page elle-même sert de point de retour après connexion.
    return window.location.origin + window.location.pathname;
  }

  function base64UrlEncode(buffer) {
    const bytes = new Uint8Array(buffer);
    let str = "";
    for (const b of bytes) str += String.fromCharCode(b);
    return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  function randomString(len) {
    const arr = new Uint8Array(len);
    crypto.getRandomValues(arr);
    return base64UrlEncode(arr.buffer).slice(0, len);
  }

  async function sha256(input) {
    const data = new TextEncoder().encode(input);
    return crypto.subtle.digest("SHA-256", data);
  }

  function extractPlaylistId(url) {
    const m = url.match(/playlist[/:]([a-zA-Z0-9]+)/);
    return m ? m[1] : null;
  }

  async function beginLogin(clientId) {
    const verifier = randomString(64);
    sessionStorage.setItem("spotify_verifier", verifier);
    const challenge = base64UrlEncode(await sha256(verifier));

    const params = new URLSearchParams({
      client_id: clientId,
      response_type: "code",
      redirect_uri: redirectUri(),
      scope: SCOPE,
      code_challenge_method: "S256",
      code_challenge: challenge,
    });
    window.location.href = "https://accounts.spotify.com/authorize?" + params.toString();
  }

  async function exchangeCode(code, clientId) {
    const verifier = sessionStorage.getItem("spotify_verifier");
    const params = new URLSearchParams({
      client_id: clientId,
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri(),
      code_verifier: verifier,
    });
    const res = await fetch("https://accounts.spotify.com/api/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    });
    if (!res.ok) throw new Error("Échange du code refusé par Spotify (vérifie le Client ID et le Redirect URI)");
    const data = await res.json();
    return data.access_token;
  }

  async function fetchPlaylistTracks(playlistId, token) {
    let url = `https://api.spotify.com/v1/playlists/${playlistId}/tracks?limit=100`;
    const items = [];
    while (url) {
      const res = await fetch(url, { headers: { Authorization: "Bearer " + token } });
      if (!res.ok) throw new Error("Lecture de la playlist refusée (HTTP " + res.status + ")");
      const data = await res.json();
      for (const item of data.items || []) {
        const track = item.track;
        if (!track) continue;
        items.push({
          title: track.name,
          artist: (track.artists || []).map(a => a.name).join(", "),
        });
      }
      url = data.next;
    }
    return items;
  }

  return { extractPlaylistId, beginLogin, exchangeCode, fetchPlaylistTracks };
})();
