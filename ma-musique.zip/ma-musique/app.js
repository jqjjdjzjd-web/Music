/* ============================================================
   Ma Musique — logique principale
   ============================================================ */

/* ---------- Petite couche IndexedDB ---------- */
const DB_NAME = "ma-musique-db";
const DB_VERSION = 1;
let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("tracks")) {
        const store = db.createObjectStore("tracks", { keyPath: "id" });
        store.createIndex("addedAt", "addedAt");
      }
      if (!db.objectStoreNames.contains("kv")) {
        db.createObjectStore("kv", { keyPath: "key" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function dbAdd(track) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("tracks", "readwrite");
    tx.objectStore("tracks").put(track);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function dbGetAll() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("tracks", "readonly");
    const req = tx.objectStore("tracks").index("addedAt").getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbDelete(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("tracks", "readwrite");
    tx.objectStore("tracks").delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function dbClearAll() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("tracks", "readwrite");
    tx.objectStore("tracks").clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function kvSet(key, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("kv", "readwrite");
    tx.objectStore("kv").put({ key, value });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function kvGet(key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("kv", "readonly");
    const req = tx.objectStore("kv").get(key);
    req.onsuccess = () => resolve(req.result ? req.result.value : undefined);
    req.onerror = () => reject(req.error);
  });
}

/* ---------- Thème ---------- */
const themeToggle = document.getElementById("theme-toggle");

function applyTheme(pref) {
  if (pref === "system") {
    document.documentElement.removeAttribute("data-theme");
  } else {
    document.documentElement.setAttribute("data-theme", pref);
  }
  [...themeToggle.querySelectorAll("button")].forEach(b => {
    b.classList.toggle("active", b.dataset.themeChoice === pref);
  });
}

function initTheme() {
  const saved = localStorage.getItem("theme") || "system";
  applyTheme(saved);
  themeToggle.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-theme-choice]");
    if (!btn) return;
    const choice = btn.dataset.themeChoice;
    localStorage.setItem("theme", choice);
    applyTheme(choice);
  });
}

/* ---------- Navigation par onglets ---------- */
function initTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("view-" + btn.dataset.view).classList.add("active");
    });
  });
}

/* ---------- Utilitaires ---------- */
function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : "id-" + Date.now() + "-" + Math.random().toString(16).slice(2);
}

function titleFromUrl(url) {
  try {
    const clean = decodeURIComponent(url.split("?")[0].split("/").pop() || "morceau");
    return clean.replace(/\.[a-zA-Z0-9]+$/, "").replace(/[_-]+/g, " ").trim() || "Morceau sans titre";
  } catch {
    return "Morceau sans titre";
  }
}

function formatTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " o";
  const units = ["Ko", "Mo", "Go"];
  let i = -1;
  do { bytes /= 1024; i++; } while (bytes >= 1024 && i < units.length - 1);
  return bytes.toFixed(1) + " " + units[i];
}

/* ---------- État ---------- */
let tracks = [];
let currentIndex = -1;
let currentObjectUrl = null;
const audioEl = document.getElementById("audio-el");

/* ---------- Rendu de la bibliothèque ---------- */
const trackListEl = document.getElementById("track-list");
const emptyStateEl = document.getElementById("empty-state");
const trackCountEl = document.getElementById("track-count");

function renderLibrary() {
  trackCountEl.textContent = tracks.length ? `${tracks.length} morceau${tracks.length > 1 ? "x" : ""}` : "";
  emptyStateEl.style.display = tracks.length ? "none" : "block";
  trackListEl.innerHTML = "";
  tracks.forEach((t, i) => {
    const li = document.createElement("li");
    li.className = "track-row" + (i === currentIndex ? " playing" : "");
    const missing = !t.blob;
    li.innerHTML = `
      <span class="num">${i + 1}</span>
      <button class="track-main">
        <div class="track-title">${escapeHtml(t.title)}${missing ? '<span class="track-badge">lien manquant</span>' : ""}</div>
        <div class="track-artist">${escapeHtml(t.artist || "Artiste inconnu")}</div>
      </button>
      <button class="track-menu-btn" data-action="delete" title="Supprimer">✕</button>
    `;
    li.querySelector(".track-main").addEventListener("click", () => {
      if (missing) {
        switchToAddTabPrefilled(t);
      } else {
        playIndex(i);
      }
    });
    li.querySelector('[data-action="delete"]').addEventListener("click", async (ev) => {
      ev.stopPropagation();
      await dbDelete(t.id);
      if (i === currentIndex) stopPlayback();
      await loadTracks();
    });
    trackListEl.appendChild(li);
  });
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str ?? "";
  return d.innerHTML;
}

function switchToAddTabPrefilled(track) {
  document.querySelector('.tab-btn[data-view="add"]').click();
  document.getElementById("input-title").value = track.title;
  document.getElementById("input-artist").value = track.artist || "";
  document.getElementById("input-url").focus();
  // remember which entry to complete
  window.__pendingCompleteId = track.id;
}

async function loadTracks() {
  tracks = await dbGetAll();
  tracks.sort((a, b) => a.addedAt - b.addedAt);
  renderLibrary();
}

/* ---------- Lecture ---------- */
const miniPlayer = document.getElementById("mini-player");
const mpTitle = document.getElementById("mp-title");
const mpArtist = document.getElementById("mp-artist");
const mpPlayPause = document.getElementById("mp-playpause");

const playerSheet = document.getElementById("player-sheet");
const playerTitle = document.getElementById("player-title");
const playerArtist = document.getElementById("player-artist");
const seekBar = document.getElementById("seek-bar");
const timeCurrent = document.getElementById("time-current");
const timeTotal = document.getElementById("time-total");
const btnPlayPause = document.getElementById("btn-playpause");

function playIndex(i) {
  const t = tracks[i];
  if (!t || !t.blob) return;
  currentIndex = i;
  if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
  currentObjectUrl = URL.createObjectURL(t.blob);
  audioEl.src = currentObjectUrl;
  audioEl.play().catch(() => {});
  updateNowPlayingUI(t);
  renderLibrary();
  updateMediaSession(t);
}

function updateNowPlayingUI(t) {
  miniPlayer.classList.add("visible");
  mpTitle.textContent = t.title;
  mpArtist.textContent = t.artist || "Artiste inconnu";
  playerTitle.textContent = t.title;
  playerArtist.textContent = t.artist || "Artiste inconnu";
}

function togglePlayPause() {
  if (audioEl.paused) audioEl.play().catch(() => {});
  else audioEl.pause();
}

function stopPlayback() {
  audioEl.pause();
  audioEl.removeAttribute("src");
  currentIndex = -1;
  miniPlayer.classList.remove("visible");
}

function playNext() {
  if (currentIndex < 0) return;
  let n = currentIndex;
  for (let step = 0; step < tracks.length; step++) {
    n = (n + 1) % tracks.length;
    if (tracks[n].blob) { playIndex(n); return; }
  }
}

function playPrev() {
  if (currentIndex < 0) return;
  let n = currentIndex;
  for (let step = 0; step < tracks.length; step++) {
    n = (n - 1 + tracks.length) % tracks.length;
    if (tracks[n].blob) { playIndex(n); return; }
  }
}

audioEl.addEventListener("play", () => {
  mpPlayPause.textContent = "⏸";
  btnPlayPause.textContent = "⏸";
  if (navigator.mediaSession) navigator.mediaSession.playbackState = "playing";
});
audioEl.addEventListener("pause", () => {
  mpPlayPause.textContent = "▶";
  btnPlayPause.textContent = "▶";
  if (navigator.mediaSession) navigator.mediaSession.playbackState = "paused";
});
audioEl.addEventListener("ended", playNext);
audioEl.addEventListener("timeupdate", () => {
  if (!isFinite(audioEl.duration)) return;
  seekBar.max = audioEl.duration;
  seekBar.value = audioEl.currentTime;
  timeCurrent.textContent = formatTime(audioEl.currentTime);
  timeTotal.textContent = formatTime(audioEl.duration);
});
seekBar.addEventListener("input", () => { audioEl.currentTime = seekBar.value; });

miniPlayer.addEventListener("click", (e) => {
  if (e.target.id === "mp-playpause") { togglePlayPause(); return; }
  playerSheet.classList.add("open");
});
mpPlayPause.addEventListener("click", (e) => { e.stopPropagation(); togglePlayPause(); });
miniPlayer.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); playerSheet.classList.add("open"); }
});
document.getElementById("player-close").addEventListener("click", () => playerSheet.classList.remove("open"));
btnPlayPause.addEventListener("click", togglePlayPause);
document.getElementById("btn-next").addEventListener("click", playNext);
document.getElementById("btn-prev").addEventListener("click", playPrev);

/* ---------- Media Session (contrôles écran verrouillé) ---------- */
function updateMediaSession(t) {
  if (!("mediaSession" in navigator)) return;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: t.title,
    artist: t.artist || "Artiste inconnu",
    album: "Ma Musique",
  });
  navigator.mediaSession.setActionHandler("play", () => audioEl.play().catch(() => {}));
  navigator.mediaSession.setActionHandler("pause", () => audioEl.pause());
  navigator.mediaSession.setActionHandler("previoustrack", playPrev);
  navigator.mediaSession.setActionHandler("nexttrack", playNext);
  navigator.mediaSession.setActionHandler("seekto", (details) => {
    if (details.seekTime != null) audioEl.currentTime = details.seekTime;
  });
}

/* ---------- Ajout de morceau ---------- */
const inputUrl = document.getElementById("input-url");
const inputTitle = document.getElementById("input-title");
const inputArtist = document.getElementById("input-artist");
const btnAdd = document.getElementById("btn-add");
const addStatus = document.getElementById("add-status");

function setStatus(el, kind, msg) {
  el.className = "status-msg show " + kind;
  el.textContent = msg;
}
function clearStatus(el) {
  el.className = "status-msg";
  el.textContent = "";
}

btnAdd.addEventListener("click", async () => {
  const url = inputUrl.value.trim();
  if (!url) { setStatus(addStatus, "error", "Colle d'abord un lien."); return; }
  btnAdd.disabled = true;
  setStatus(addStatus, "info", "Téléchargement en cours…");
  try {
    const res = await fetch(url, { mode: "cors" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const blob = await res.blob();
    const title = inputTitle.value.trim() || titleFromUrl(url);
    const artist = inputArtist.value.trim();

    if (window.__pendingCompleteId) {
      const existing = tracks.find(t => t.id === window.__pendingCompleteId);
      if (existing) {
        existing.blob = blob;
        existing.sourceUrl = url;
        if (title) existing.title = title;
        if (artist) existing.artist = artist;
        await dbAdd(existing);
        window.__pendingCompleteId = null;
        setStatus(addStatus, "ok", "Morceau complété avec l'audio ✓");
        await loadTracks();
        resetAddForm();
        btnAdd.disabled = false;
        return;
      }
    }

    const track = { id: uuid(), title, artist, sourceUrl: url, blob, addedAt: Date.now() };
    await dbAdd(track);
    setStatus(addStatus, "ok", `« ${title} » ajouté à ta bibliothèque ✓`);
    await loadTracks();
    resetAddForm();
  } catch (err) {
    setStatus(addStatus, "error",
      "Impossible de récupérer ce fichier. Le lien est peut-être invalide, ou le serveur qui l'héberge bloque le téléchargement direct depuis un navigateur (CORS).");
  } finally {
    btnAdd.disabled = false;
  }
});

function resetAddForm() {
  inputUrl.value = "";
  inputTitle.value = "";
  inputArtist.value = "";
}

/* ---------- Réglages ---------- */
document.getElementById("btn-clear-library").addEventListener("click", async () => {
  if (!confirm("Supprimer tous les morceaux de la bibliothèque ? Cette action est irréversible.")) return;
  stopPlayback();
  await dbClearAll();
  await loadTracks();
});

async function updateStorageUsage() {
  const el = document.getElementById("storage-usage");
  if (navigator.storage && navigator.storage.estimate) {
    const { usage } = await navigator.storage.estimate();
    el.textContent = formatBytes(usage || 0) + " utilisés sur cet appareil";
  } else {
    el.textContent = "Non disponible sur ce navigateur";
  }
}

const inputSpotifyClientId = document.getElementById("input-spotify-client-id");
inputSpotifyClientId.addEventListener("change", async () => {
  await kvSet("spotifyClientId", inputSpotifyClientId.value.trim());
});

/* ---------- Import Spotify ---------- */
const inputSpotify = document.getElementById("input-spotify");
const btnSpotifyImport = document.getElementById("btn-spotify-import");
const spotifyStatus = document.getElementById("spotify-status");

btnSpotifyImport.addEventListener("click", async () => {
  const url = inputSpotify.value.trim();
  const clientId = (await kvGet("spotifyClientId")) || "";
  if (!clientId) {
    setStatus(spotifyStatus, "error", "Configure d'abord ton identifiant Spotify dans Réglages.");
    return;
  }
  const playlistId = SpotifyImport.extractPlaylistId(url);
  if (!playlistId) {
    setStatus(spotifyStatus, "error", "Ce lien ne ressemble pas à une playlist Spotify.");
    return;
  }
  setStatus(spotifyStatus, "info", "Redirection vers Spotify pour autorisation…");
  await kvSet("pendingPlaylistId", playlistId);
  await SpotifyImport.beginLogin(clientId);
});

async function finishSpotifyImportIfNeeded() {
  const params = new URLSearchParams(window.location.search);
  if (!params.has("code")) return;
  const code = params.get("code");
  window.history.replaceState({}, "", window.location.pathname);
  document.querySelector('.tab-btn[data-view="add"]').click();
  setStatus(spotifyStatus, "info", "Récupération des titres…");
  try {
    const clientId = (await kvGet("spotifyClientId")) || "";
    const playlistId = await kvGet("pendingPlaylistId");
    const token = await SpotifyImport.exchangeCode(code, clientId);
    const items = await SpotifyImport.fetchPlaylistTracks(playlistId, token);
    let added = 0;
    for (const item of items) {
      const exists = tracks.some(t => t.title === item.title && t.artist === item.artist);
      if (exists) continue;
      await dbAdd({
        id: uuid(),
        title: item.title,
        artist: item.artist,
        sourceUrl: "",
        blob: null,
        addedAt: Date.now(),
      });
      added++;
    }
    await loadTracks();
    setStatus(spotifyStatus, "ok",
      `${added} titre${added > 1 ? "s" : ""} importé${added > 1 ? "s" : ""}. Ouvre chacun depuis la bibliothèque pour coller son lien audio.`);
  } catch (err) {
    setStatus(spotifyStatus, "error", "L'import a échoué : " + err.message);
  }
}

/* ---------- Service worker ---------- */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}

/* ---------- Démarrage ---------- */
(async function init() {
  initTheme();
  initTabs();
  const savedClientId = await kvGet("spotifyClientId");
  if (savedClientId) inputSpotifyClientId.value = savedClientId;
  await loadTracks();
  await updateStorageUsage();
  await finishSpotifyImportIfNeeded();
})();
