const CACHE_NAME = "ma-musique-shell-v1";
const SHELL_FILES = [
  "./",
  "./index.html",
  "./styles.css",
  "./app.js",
  "./spotify.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// App shell: cache-first. Everything else (Spotify API, audio downloads
// triggered by fetch() in app.js): pass through to the network untouched,
// since audio files are stored in IndexedDB by the app itself, not here.
const SHELL_URLS = new Set(SHELL_FILES.map((f) => new URL(f, self.registration.scope).href));

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  if (!SHELL_URLS.has(event.request.url)) return; // same-origin app files only

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
